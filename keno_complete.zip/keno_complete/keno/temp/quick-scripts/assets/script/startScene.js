(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/startScene.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd50c26GAN9GurKjWMCC2QKR', 'startScene', __filename);
// script/startScene.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        btnPlay: {
            default: null,
            type: cc.Button
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {},
    start: function start() {
        //cc.view.resizeWithBrowserSize(true);
        //cc.view.setDesignResolutionSize(1024, 768, cc.ResolutionPolicy.EXACT_FIT);
        cc.screen.fullScreen();
        cc.audioEngine.stopAll();
        var audio = cc.url.raw("resources/sound/bg.mp3");
        cc.audioEngine.play(audio, true, 1);
        this.btnPlay.node.on(cc.Node.EventType.MOUSE_ENTER, this.mouseOver);
        this.btnPlay.node.on(cc.Node.EventType.MOUSE_LEAVE, this.mouseLeave);
    },

    play: function play() {
        cc.director.loadScene("main_game");
    },
    mouseOver: function mouseOver() {
        cc.log("btnplay_mouse_over");
    },
    mouseLeave: function mouseLeave() {
        cc.log("btnplay_mouse_leave");
    }
    // update (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=startScene.js.map
        